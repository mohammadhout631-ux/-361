/**
 * Admin Panel Logic
 */

const Admin = {
    isLoggedIn: false,

    login: function () {
        const pass = document.getElementById('admin-pass').value;
        const data = RestaurantData.getData();

        if (pass === data.info.adminPassword) {
            this.isLoggedIn = true;
            document.getElementById('login-overlay').style.display = 'none';
            this.init();
        } else {
            alert('❌ كلمة السر خاطئة!');
        }
    },

    logout: function () {
        if (confirm('هل تريد تسجيل الخروج؟')) {
            window.location.reload();
        }
    },

    init: function () {
        const data = RestaurantData.getData();
        this.fillInfo(data.info);
        this.renderCategoriesList();
        this.fillItemCategoryFilter();
        this.renderItemsList();
    },

    showTab: function (tabName, event) {
        if (event) event.preventDefault();
        document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
        document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('active'));

        document.getElementById('tab-' + tabName).style.display = 'block';
        if (event) event.target.closest('.tab-link').classList.add('active');
    },

    // Restaurant Info
    fillInfo: function (info) {
        document.getElementById('info-name').value = info.name;
        document.getElementById('info-phone').value = info.phone;
        document.getElementById('info-address').value = info.address;
        document.getElementById('info-hours').value = info.openHours;
        const geminiInput = document.getElementById('gemini-key');
        if (geminiInput) geminiInput.value = info.geminiKey || '';
    },

    saveInfo: function () {
        const data = RestaurantData.getData();
        data.info.name = document.getElementById('info-name').value;
        data.info.phone = document.getElementById('info-phone').value;
        data.info.address = document.getElementById('info-address').value;
        data.info.openHours = document.getElementById('info-hours').value;

        if (RestaurantData.saveData(data)) {
            alert('✅ تم حفظ المعلومات بنجاح');
        }
    },

    saveGeminiKey: function () {
        const key = document.getElementById('gemini-key').value;
        if (!key) return alert('الرجاء إدخال مفتاح API');

        const data = RestaurantData.getData();
        data.info.geminiKey = key;
        if (RestaurantData.saveData(data)) {
            alert('✅ تم حفظ مفتاح الذكاء الاصطناعي بنجاح');
        }
    },

    // Categories
    renderCategoriesList: function () {
        const data = RestaurantData.getData();
        const list = document.getElementById('categories-list');
        list.innerHTML = '';

        data.categories.sort((a, b) => a.order - b.order).forEach(cat => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${cat.order}</td>
                <td><input type="text" value="${cat.name}" onchange="Admin.updateCategoryName('${cat.id}', this.value)" style="width:100%; padding:5px; background:transparent; color:white; border:1px solid #333;"></td>
                <td>
                    <button onclick="Admin.deleteCategory('${cat.id}')" class="btn" style="background:var(--danger); padding:5px 10px;"><i class="fas fa-trash"></i></button>
                </td>
            `;
            list.appendChild(tr);
        });
    },

    addCategory: function () {
        const name = prompt('أدخل اسم القسم الجديد:');
        if (!name) return;

        const data = RestaurantData.getData();
        const newId = 'c_' + Date.now();
        data.categories.push({
            id: newId,
            name: name,
            order: data.categories.length + 1
        });

        RestaurantData.saveData(data);
        this.renderCategoriesList();
        this.fillItemCategoryFilter();
    },

    updateCategoryName: function (id, newName) {
        const data = RestaurantData.getData();
        const cat = data.categories.find(c => c.id === id);
        if (cat) cat.name = newName;
        RestaurantData.saveData(data);
    },

    deleteCategory: function (id) {
        if (!confirm('هل أنت متأكد؟ سيتم حذف جميع الأصناف في هذا القسم!')) return;
        const data = RestaurantData.getData();
        data.categories = data.categories.filter(c => c.id !== id);
        data.items = data.items.filter(i => i.categoryId !== id);
        RestaurantData.saveData(data);
        this.renderCategoriesList();
        this.renderItemsList();
    },

    // Items
    fillItemCategoryFilter: function () {
        const data = RestaurantData.getData();
        const filter = document.getElementById('item-cat-filter');
        filter.innerHTML = '<option value="all">كل الأقسام</option>';
        data.categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.id;
            opt.innerText = cat.name;
            filter.appendChild(opt);
        });
    },

    renderItemsList: function () {
        const data = RestaurantData.getData();
        const list = document.getElementById('items-list');
        const filterId = document.getElementById('item-cat-filter').value;
        list.innerHTML = '';

        const filteredItems = filterId === 'all' ? data.items : data.items.filter(i => i.categoryId === filterId);

        filteredItems.forEach(item => {
            const cat = data.categories.find(c => c.id === item.categoryId);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${item.image ? `<img src="${item.image}" width="40">` : '<i class="fas fa-utensils"></i>'}</td>
                <td><input type="text" value="${item.name}" onchange="Admin.updateItem('${item.id}', 'name', this.value)" style="background:transparent; color:white; border:none; border-bottom:1px solid #333;"></td>
                <td><input type="text" value="${item.price}" onchange="Admin.updateItem('${item.id}', 'price', this.value)" style="width:60px; background:transparent; color:var(--primary); border:none; border-bottom:1px solid #333;"></td>
                <td style="font-size:12px; color:#aaa;">${cat ? cat.name : 'بدون قسم'}</td>
                <td>
                    <button onclick="Admin.editItemImage('${item.id}')" class="btn" style="background:var(--primary); color:#000; padding:5px 10px;"><i class="fas fa-image"></i></button>
                    <button onclick="Admin.deleteItem('${item.id}')" class="btn" style="background:var(--danger); padding:5px 10px;"><i class="fas fa-trash"></i></button>
                </td>
            `;
            list.appendChild(tr);
        });
    },

    addItem: function () {
        const data = RestaurantData.getData();
        if (data.categories.length === 0) {
            alert('يرجى إنشاء قسم أولاً!');
            return;
        }

        const name = prompt('اسم الصنف الجديد:');
        if (!name) return;
        const price = prompt('السعر:');
        const catId = document.getElementById('item-cat-filter').value;
        const targetCatId = catId === 'all' ? data.categories[0].id : catId;

        const newItem = {
            id: 'i_' + Date.now(),
            categoryId: targetCatId,
            name: name,
            price: price || '0',
            image: ''
        };

        data.items.push(newItem);
        RestaurantData.saveData(data);
        this.renderItemsList();
    },

    updateItem: function (id, field, value) {
        const data = RestaurantData.getData();
        const item = data.items.find(i => i.id === id);
        if (item) item[field] = value;
        RestaurantData.saveData(data);
    },

    deleteItem: function (id) {
        if (!confirm('هل أنت متأكد من حذف هذا الصنف؟')) return;
        const data = RestaurantData.getData();
        data.items = data.items.filter(i => i.id !== id);
        RestaurantData.saveData(data);
        this.renderItemsList();
    },

    editItemImage: function (id) {
        const input = document.getElementById('item-image-input');
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Check file size (limit to 1MB for localStorage)
            if (file.size > 1024 * 1024) {
                alert('⚠️ الصورة كبيرة جداً! يرجى اختيار صورة أصغر من 1 ميجا بايت.');
                return;
            }

            const reader = new FileReader();
            reader.onload = (event) => {
                const base64 = event.target.result;
                this.updateItem(id, 'image', base64);
                this.renderItemsList();
                alert('✅ تم تحديث الصورة بنجاح');
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    // Backup
    exportData: function () {
        const json = RestaurantData.exportData();
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `al-hout-menu-${new Date().toLocaleDateString()}.json`;
        a.click();
    },

    importData: function (input) {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            if (RestaurantData.importData(e.target.result)) {
                alert('✅ تم استيراد البيانات بنجاح!');
                window.location.reload();
            } else {
                alert('❌ فشل استيراد البيانات!');
            }
        };
        reader.readAsText(file);
    }
};
