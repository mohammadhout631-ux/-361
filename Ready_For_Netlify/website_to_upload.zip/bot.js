/**
 * 🎤 VOICE WAITER BOT V1.0
 * -------------------------------------
 * - Voice-only interaction (no text chat)
 * - Arabic & English support
 * - Acts as restaurant waiter
 * - Reads data from website
 * - Mobile-responsive floating button
 */

(function () {
  console.log("🎤 Voice Bot V1.0 Loaded!");
  // alert("Voice Bot Loaded! Click the yellow mic button.");

  var DB_KEY = "REST_OS_V8_PRO_STABLE";
  var BAKED_DATA = { "meta": { "version": "8.5.0" }, "info": { "name": "مطعم الحوت | Al-Hout Rest", "phone": "03 631 903", "address": "Bhamdoun Al Day3a - بحمدون الضيعة", "currency": "$", "openHours": "12:00 PM - 12:00 AM", "welcomeMsg": "أهلا وسهلا فيك بمطعم الحوت 🐋\nكيف فيني أساعدك اليوم؟ 😊", "adminPassword": "1234", "botActive": true }, "inventory": [{ "id": "c_1", "name": "حلويات", "items": [{ "id": 1767411830009, "name": "ليزي كيك", "price": "6 $", "available": true }, { "id": 1767411868993, "name": "بوظة دق مع غزل البنات", "price": "10 $", "available": true }] }, { "id": 1767411154313, "name": "مناقيش صاج", "items": [{ "id": 1767411202618, "name": "زعتر", "price": "2 $", "available": true }, { "id": 1767411251393, "name": "جبنة", "price": "4 $", "available": true }, { "id": 1767411289713, "name": "زعتر ولبنة", "price": "3 $", "available": true }, { "id": 1767411313433, "name": "لبنة", "price": "3 $", "available": true }, { "id": 1767411334281, "name": "كشك", "price": "3 $", "available": true }, { "id": 1767411359825, "name": "كشك وجبنة", "price": "4 $", "available": true }, { "id": 1767411382785, "name": "محمره", "price": "3 $", "available": true }, { "id": 1767411410393, "name": "محمره بالجبنة", "price": "4 $", "available": true }, { "id": 1767411441121, "name": "بندورة وبصل", "price": "3 $", "available": true }, { "id": 1767411465185, "name": "بندورة وبصل وجبنة", "price": "4 $", "available": true }, { "id": 1767411494577, "name": "سجق وجبنة", "price": "7 $", "available": true }, { "id": 1767411521409, "name": "حبش وجبنة", "price": "7 $", "available": true }, { "id": 1767411544378, "name": "جبنة مكس", "price": "5 $", "available": true }, { "id": 1767411584577, "name": "كوكتيل زعتر وجبنة", "price": "4 $", "available": true }, { "id": 1767411612841, "name": "بيتزا مارغريتا", "price": "6 $", "available": true }, { "id": 1767411642425, "name": "بيتزا مارغريتا", "price": "8 $", "available": true }, { "id": 1767411660025, "name": "بيتزا حبش", "price": "8 $", "available": true }, { "id": 1767411680193, "name": "بيتزا خضار", "price": "8 $", "available": true }, { "id": 1767411704769, "name": "نوتيلا", "price": "5 $", "available": true }, { "id": 1767411733913, "name": "رغيف صباح", "price": "0.5 $", "available": true }] }, { "id": 1767411900978, "name": " أطباق رئيسية", "items": [{ "id": 1767411930153, "name": "صحن برغر لحمة", "price": "10 $", "available": true }, { "id": 1767411947897, "name": "صحن برغر دجاج", "price": "8 $", "available": true }, { "id": 1767411970818, "name": "صحن طاووق", "price": "8 $", "available": true }, { "id": 1767411998489, "name": "صحن اسكلوب", "price": "8 $", "available": true }, { "id": 1767412015201, "name": "سفاين دجاج", "price": "10 $", "available": true }, { "id": 1767412038537, "name": "صحن ناغتس", "price": "6 $", "available": true }, { "id": 1767412059321, "name": "صحن بطاطا", "price": "4 $", "available": true }, { "id": 1767412077777, "name": "صحن بطاطا ودجيز", "price": "4 $", "available": true }] }, { "id": 1767412106257, "name": " مقبلات", "items": [{ "id": 1767412133185, "name": "صحن حمص", "price": "4 $", "available": true }, { "id": 1767412176737, "name": "صحن متبل بازنجان", "price": "4 $", "available": true }, { "id": 1767412199969, "name": "صحن خضار", "price": "4 $", "available": true }, { "id": 1767412221441, "name": "صحن فتوش", "price": "7 $", "available": true }, { "id": 1767412246522, "name": "صحن لبنة", "price": "6 $", "available": true }, { "id": 1767412274425, "name": "صحن لبنة مع ثوم", "price": "7 $", "available": true }, { "id": 1767412302801, "name": "صحن بيض", "price": "6 $", "available": true }, { "id": 1767412326465, "name": "صحن بيض مع سجق", "price": "10 $", "available": true }, { "id": 1767412349097, "name": "صحن مكدوس", "price": "6 $", "available": true }, { "id": 1767412377233, "name": "سلطة سيزر", "price": "12 $", "available": true }, { "id": 1767412403049, "name": "بطاطا مشوية", "price": "7 $", "available": true }] }, { "id": 1767412438945, "name": " لقمشات ومقرمشات", "items": [{ "id": 1767412469682, "name": "تشبس", "price": "2 $", "available": true }, { "id": 1767412491649, "name": "بوشار", "price": "3 $", "available": true }, { "id": 1767412509946, "name": "جزر", "price": "4 $", "available": true }, { "id": 1767412527009, "name": "بزورات", "price": "4 $", "available": true }, { "id": 1767412548089, "name": "ترمس", "price": "4 $", "available": true }, { "id": 1767412569137, "name": "ترمس وجزر", "price": "5 $", "available": true }, { "id": 1767412586329, "name": "حامض وجزر", "price": "5 $", "available": true }, { "id": 1767412604929, "name": "حامض وجزر وترمس", "price": "6 $", "available": true }, { "id": 1767412621009, "name": "ذرة وحامض", "price": "5 $", "available": true }, { "id": 1767412639017, "name": "ذرة وجبنة", "price": "6 $", "available": true }, { "id": 1767412661425, "name": "قلوبات", "price": "7 $", "available": true }, { "id": 1767412692761, "name": "ادمامي", "price": "7 $", "available": true }] }, { "id": 1767412714026, "name": " مشروبات ساخنة", "items": [{ "id": 1767412743841, "name": "قهوة تركية", "price": "2 $", "available": true }, { "id": 1767412761265, "name": "قهوة اكسبريسو", "price": "2 $", "available": true }, { "id": 1767412778769, "name": "قهوة بيضاء", "price": "2 $", "available": true }, { "id": 1767412796745, "name": "نسكافيه", "price": "3 $", "available": true }, { "id": 1767412821785, "name": "كابتشينو", "price": "3 $", "available": true }, { "id": 1767412846448, "name": "شاي", "price": "3 $", "available": true }, { "id": 1767412864177, "name": "شاي أخضر", "price": "3 $", "available": true }, { "id": 1767412881201, "name": "كمون", "price": "3 $", "available": true }, { "id": 1767412895809, "name": "زنجبيل وعسل", "price": "3 $", "available": true }, { "id": 1767412915546, "name": "نعناع", "price": "3 $", "available": true }, { "id": 1767412937697, "name": "زهورات", "price": "3 $", "available": true }, { "id": 1767412964665, "name": "بابونج", "price": "3 $", "available": true }, { "id": 1767412980033, "name": " يانسون", "price": "3 $", "available": true }, { "id": 1767412994001, "name": "كانارينو", "price": "2 $", "available": true }, { "id": 1767413012394, "name": "هوت شوكلت", "price": "5 $", "available": true }, { "id": 1767413030714, "name": "سحلب", "price": "4 $", "available": true }] }, { "id": 1767413057001, "name": " مشروبات باردة", "items": [{ "id": 1767413098745, "name": "دارك بلو", "price": "4 $", "available": true }, { "id": 1767413116905, "name": "بوم بوم", "price": "5 $", "available": true }, { "id": 1767413138338, "name": "بيبسي", "price": "2 $", "available": true }, { "id": 1767413154154, "name": "سفن أب", "price": "2 $", "available": true }, { "id": 1767413172122, "name": "ميرندا", "price": "2 $", "available": true }, { "id": 1767413190761, "name": "آيس تي", "price": "3 $", "available": true }, { "id": 1767413209849, "name": "ليزرة", "price": "4 $", "available": true }, { "id": 1767413232985, "name": "ليزرة مكس كن", "price": "5 $", "available": true }, { "id": 1767413255866, "name": "غرانادين أو هواي", "price": "1 $", "available": true }, { "id": 1767413576850, "name": "الوافيرا", "price": "7 $", "available": true }, { "id": 1767413610073, "name": "آيس كوفي", "price": "5 $", "available": true }] }, { "id": 1767413286818, "name": " مشروبات كوكتال وعصائر طازجة", "items": [{ "id": 1767413322657, "name": "فريرز", "price": "6 $", "available": true }, { "id": 1767413340713, "name": "مانغا", "price": "6 $", "available": true }, { "id": 1767413430833, "name": "ليموناضة", "price": "5 $", "available": true }, { "id": 1767413451618, "name": "ليموناضة بالنعناع", "price": "5 $", "available": true }, { "id": 1767413478425, "name": "ليمون", "price": "5 $", "available": true }, { "id": 1767413494770, "name": "كوكتال", "price": "7 $", "available": true }, { "id": 1767413514489, "name": "ميلك شيك فراولة", "price": "7 $", "available": true }, { "id": 1767413537553, "name": "ميلك شيك شوكولاتة", "price": "7 $", "available": true }, { "id": 1767413697858, "name": "موز وفرازة", "price": "6 $", "available": true }, { "id": 1767413714945, "name": "حليب وموز", "price": "6 $", "available": true }, { "id": 1767413733106, "name": "ميلك شيك كراميل", "price": "7 $", "available": true }, { "id": 1767413754338, "name": "ماء كبير", "price": "2 $", "available": true }, { "id": 1767413771025, "name": "ماء صغير", "price": "1 $", "available": true }, { "id": 1767413790625, "name": "كوب ثلج", "price": "1 $", "available": true }, { "id": 1767413808089, "name": "ماء غازية", "price": "3 $", "available": true }] }, { "id": 1767413830153, "name": "أراكيل", "items": [{ "id": 1767413852794, "name": "تفاحتين", "price": "10 $", "available": true }, { "id": 1767413872017, "name": "حامض ونعناع", "price": "10 $", "available": true }, { "id": 1767413894049, "name": "عنب", "price": "10 $", "available": true }, { "id": 1767413909707, "name": "عنب ونعناع", "price": "10 $", "available": true }, { "id": 1767413925905, "name": "عجمي", "price": "10 $", "available": true }, { "id": 1767413941242, "name": "نكهة", "price": "8 $", "available": true }, { "id": 1767413962707, "name": "فرش", "price": "15 $", "available": true }, { "id": 1767413996761, "name": "نريش بلاستيك", "price": "2 $", "available": true }] }], "knowledge_base": [{ "id": "k_1", "tags": "wifi,نت,واي فاي", "answer": "الإنترنت عنا سريع ومجاني! 📶" }] };

  var Store = {
    data: {},
    load: function () {
      try {
        var raw = localStorage.getItem(DB_KEY);
        if (raw) {
          this.data = JSON.parse(raw);
          if (!this.data.info) this.data.info = BAKED_DATA.info;
          if (!this.data.inventory) this.data.inventory = BAKED_DATA.inventory;
        } else {
          this.data = BAKED_DATA;
        }
      } catch (e) {
        this.data = BAKED_DATA;
      }
    },
    save: function () {
      localStorage.setItem(DB_KEY, JSON.stringify(this.data));
      Renderer.updateUI();
    }
  };

  var Utils = {
    normalize: function (txt) {
      if (!txt) return "";
      txt = txt.toLowerCase().trim();
      txt = txt.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/^ال/g, "");
      return txt;
    }
  };

  var Agent = {
    API_KEY: 'AIzaSyDhgN139EpeTWy2_A0NkACcUmlQiwXrsjc',
    API_URL: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',

    think: async function (input) {
      if (!input) return "...";

      // Admin check first
      var t = Utils.normalize(input);
      if (t.match(/admin|settings|عدادات|ادمن/i)) {
        return "ADMIN_TRIGGER";
      }

      // Build context from restaurant data
      var info = Store.data.info;
      var inv = Store.data.inventory || [];

      var menuText = "";
      for (var i = 0; i < inv.length; i++) {
        menuText += "\n" + inv[i].name + ":\n";
        for (var j = 0; j < inv[i].items.length; j++) {
          menuText += "  - " + inv[i].items[j].name + ": " + inv[i].items[j].price + "\n";
        }
      }

      var systemPrompt = `أنت نادل محترف في مطعم الحوت (Al-Hout Restaurant).

معلومات المطعم:
- الاسم: ${info.name}
- الهاتف: ${info.phone}
- العنوان: ${info.address}
- ساعات العمل: ${info.openHours}

المنيو الكامل:${menuText}

شخصيتك:
- تتكلم بلهجة لبنانية ودية وطبيعية
- تكون مهذب ومحترف
- تساعد الزبائن باختيار الطعام
- تقترح أطباق إضافية بذكاء (upselling)
- ترد بنفس لغة السؤال (عربي أو إنجليزي)
- تستخدم إيموجي بشكل خفيف
- لا تخترع أسعار أو أطباق غير موجودة بالمنيو

تعليمات:
- إذا سألوك عن طبق معين، أعطي السعر من المنيو
- إذا سألوك عن فئة (مثل مشروبات)، اذكر الخيارات
- اقترح أطباق مكملة بذكاء
- كن ودود وطبيعي في الحديث

رد الآن على سؤال الزبون:`;

      try {
        var response = await fetch(this.API_URL + '?key=' + this.API_KEY, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: systemPrompt + "\n\nالزبون: " + input
              }]
            }],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 200
            }
          })
        });

        var data = await response.json();

        if (data.candidates && data.candidates[0] && data.candidates[0].content) {
          return data.candidates[0].content.parts[0].text;
        } else {
          console.error("Gemini API Error:", data);
          return "عذراً، في مشكلة بالاتصال. فيك تعيد السؤال؟";
        }
      } catch (error) {
        console.error("API Error:", error);
        return "عذراً، في مشكلة تقنية. جرب مرة تانية بعد شوي.";
      }
    }
  };

  var Renderer = {
    updateUI: function () {
      var d = Store.data, ph = document.getElementById("phone-display"), ad = document.getElementById("address-display"), cont = document.getElementById("menu-container");
      if (ph) ph.innerText = d.info.phone || "";
      if (ad) ad.innerText = d.info.address || "";
      if (cont) {
        cont.innerHTML = "";
        var inv = d.inventory || [];
        for (var i = 0; i < inv.length; i++) {
          if (!inv[i].items || inv[i].items.length === 0) continue;
          var h = document.createElement("h3");
          h.innerText = inv[i].name;
          h.style.cssText = "grid-column:1/-1; border-bottom:1px solid #f5e60d; padding:10px 0; color:#f5e60d; margin-top:20px";
          cont.appendChild(h);
          for (var j = 0; j < inv[i].items.length; j++) {
            var itm = inv[i].items[j], div = document.createElement("div");
            div.style.cssText = "background:#1e1e1e; padding:15px; border-radius:10px; display:flex; justify-content:space-between; margin-bottom:10px; border:1px solid #333";
            div.innerHTML = "<div><b style='color:#fff'>" + itm.name + "</b></div><span style='color:#f5e60d; font-weight:bold'>" + itm.price + "</span>";
            cont.appendChild(div);
          }
        }
      }
    }
  };

  var CMS = {
    open: function () {
      try {
        var p = prompt("🔐 أدخل كلمة السر للدخول إلى لوحة التحكم:\n(كلمة السر الافتراضية: 1234)", "");
        if (p === null) return;
        p = p ? p.trim() : "";
        if (p == Store.data.info.adminPassword) {
          setTimeout(function () {
            try {
              CMS.showPanel();
            } catch (e) {
              alert("Error: " + e.message);
            }
          }, 100);
        } else {
          alert("❌ كلمة السر خاطئة!\n\nكلمة السر الافتراضية هي: " + Store.data.info.adminPassword);
        }
      } catch (e) {
        alert("Error: " + e.message);
      }
    },
    showPanel: function () {
      if (document.getElementById("cms-v10-9")) return;
      try {
        var ov = document.createElement("div");
        ov.id = "cms-v10-9";
        Object.assign(ov.style, {
          position: "fixed", top: 0, left: 0,
          width: "100%", height: "100%",
          background: "#111", zIndex: 1000000,
          color: "white", display: "flex", flexDirection: "column"
        });

        ov.innerHTML = '<div style="background:#222; padding:15px; border-bottom:1px solid #f5e60d; display:flex; justify-content:space-between; align-items:center"><span>لوحة التحكم ⚙️</span><button id="cms-x-btn" style="background:red; color:white; border:none; padding:8px 20px; border-radius:10px; cursor:pointer">إغلاق</button></div>' +
          '<div style="background:#333; display:flex"><button class="t-b-f" data-t="inv" style="flex:1; padding:15px; background:#444; color:white; border:none; cursor:pointer">🍽️ المنيو</button><button class="t-b-f" data-t="set" style="flex:1; padding:15px; background:#222; color:#888; border:none; cursor:pointer">⚙️ الإعدادات</button></div>' +
          '<div id="cms-pane-f" style="flex:1; padding:20px; overflow-y:auto"></div>';
        document.body.appendChild(ov);

        document.getElementById("cms-x-btn").onclick = function () { ov.remove(); };
        var tabs = ov.querySelectorAll(".t-b-f");
        for (var i = 0; i < tabs.length; i++) {
          tabs[i].onclick = function () {
            for (var j = 0; j < tabs.length; j++) { tabs[j].style.background = "#222"; tabs[j].style.color = "#888"; }
            this.style.background = "#444"; this.style.color = "white";
            CMS.render(this.getAttribute("data-t"));
          };
        }
        this.render("inv");
      } catch (e) {
        alert("Error: " + e.message);
      }
    },
    render: function (tab) {
      var self = this, pane = document.getElementById("cms-pane-f");
      pane.innerHTML = "";
      if (tab === "inv") {
        var inv = Store.data.inventory || [];
        for (var i = 0; i < inv.length; i++) {
          (function (c) {
            var d = document.createElement("div");
            d.style.cssText = "border:1px solid #333; padding:15px; margin-bottom:20px; background:#222; border-radius:12px";
            d.innerHTML = '<div style="display:flex; justify-content:space-between; margin-bottom:12px"><b>' + c.name + '</b></div><div class="grid" style="display:grid; grid-template-columns:1fr 1fr; gap:10px"></div>';
            var grid = d.querySelector(".grid");
            for (var j = 0; j < c.items.length; j++) {
              (function (itm) {
                var b = document.createElement("div");
                b.style.cssText = "background:#333; padding:10px; border-radius:8px";
                b.innerHTML = '<div>' + itm.name + '<br><small style="color:#f5e60d">' + itm.price + '</small></div>';
                grid.appendChild(b);
              })(c.items[j]);
            }
            pane.appendChild(d);
          })(inv[i]);
        }
      } else if (tab === "set") {
        pane.innerHTML = '<div style="padding:20px; background:#222; border-radius:15px; border:1px solid #f5e60d"><h3 style="color:#f5e60d; margin-top:0">⚙️ الإعدادات</h3><p>لوحة الإعدادات قيد التطوير...</p></div>';
      }
    }
  };

  var VoiceBot = {
    recognition: null,
    synth: window.speechSynthesis,
    isListening: false,
    isSpeaking: false,
    currentLang: 'ar-SA',

    init: function () {
      if (document.getElementById("voice-bot-root")) return;

      // Setup Speech Recognition
      var SpeechReq = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechReq) {
        this.recognition = new SpeechReq();
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'ar-SA';


        var self = this;
        this.recognition.onresult = function (event) {
          var text = event.results[0][0].transcript;
          self.isListening = false;
          self.updateStatus("thinking");

          // Handle async Agent.think
          Agent.think(text).then(function (response) {
            if (response === "ADMIN_TRIGGER") {
              CMS.open();
            } else {
              self.speak(response);
            }
          }).catch(function (error) {
            console.error("Agent error:", error);
            self.speak("عذراً، في مشكلة. جرب مرة تانية.");
            self.updateStatus("idle");
          });
        };

        this.recognition.onerror = function () {
          self.isListening = false;
          self.updateStatus("idle");
        };

        this.recognition.onend = function () {
          self.isListening = false;
          self.updateStatus("idle");
        };
      }

      // Create UI
      var html = '<div id="voice-panel" style="display:none; position:fixed; bottom:100px; right:20px; width:320px; background:#121212; border:2px solid #f5e60d; border-radius:20px; z-index:999998; padding:20px; box-shadow:0 10px 30px rgba(0,0,0,0.7); font-family:sans-serif;">' +
        '<div style="text-align:center; margin-bottom:15px;"><h3 style="color:#f5e60d; margin:0 0 5px 0;">🎤 النادل الصوتي</h3><small id="voice-status" style="color:#aaa;">اضغط للتحدث</small></div>' +
        '<div style="text-align:center; margin:20px 0;"><button id="voice-mic-btn" style="width:100px; height:100px; background:#f5e60d; border:none; border-radius:50%; font-size:40px; cursor:pointer; box-shadow:0 5px 15px rgba(245,230,13,0.4); transition:0.3s;">🎤</button></div>' +
        '<div style="text-align:center;"><button id="test-speak-btn" style="background:#2ecc71; color:white; border:none; padding:8px 15px; border-radius:8px; cursor:pointer; font-size:12px; margin-top:10px;">🔊 اختبار الصوت</button></div>' +
        '</div>' +
        '<button id="voice-fab" style="position:fixed; bottom:20px; right:20px; width:65px; height:65px; background:linear-gradient(135deg, #f5e60d, #f9a825); border-radius:50%; border:none; font-size:30px; cursor:pointer; z-index:999999; box-shadow:0 8px 20px rgba(245,230,13,0.5); transition:0.3s;">🎤</button>' +
        '<style>' +
        '.listening { animation: pulse-mic 1.5s infinite; background:#ff4757 !important; }' +
        '@keyframes pulse-mic { 0%, 100% { transform:scale(1); box-shadow:0 0 0 0 rgba(255,71,87,0.7); } 50% { transform:scale(1.1); box-shadow:0 0 0 20px rgba(255,71,87,0); } }' +
        '.speaking { background:#2ecc71 !important; }' +
        '@media (max-width: 480px) { #voice-panel { width:90%; right:5%; left:5%; } }' +
        '</style>';

      var root = document.createElement("div");
      root.id = "voice-bot-root";
      root.innerHTML = html;
      document.body.appendChild(root);

      var panel = document.getElementById("voice-panel");
      var fab = document.getElementById("voice-fab");
      var micBtn = document.getElementById("voice-mic-btn");
      var testBtn = document.getElementById("test-speak-btn");

      fab.onclick = function () {
        var isHidden = panel.style.display === 'none';
        panel.style.display = isHidden ? 'block' : 'none';
        fab.style.transform = isHidden ? 'scale(0.9) rotate(90deg)' : 'scale(1) rotate(0)';
      };

      micBtn.onclick = function () {
        if (!VoiceBot.recognition) {
          alert("متصفحك لا يدعم التعرف على الصوت. جرب Chrome أو Edge.");
          return;
        }
        if (VoiceBot.isListening) {
          VoiceBot.recognition.stop();
        } else {
          VoiceBot.startListening();
        }
      };

      // Test speak button
      if (testBtn) {
        testBtn.onclick = function () {
          console.log("Test button clicked!");
          VoiceBot.speak("مرحبا! أنا النادل الذكي. الصوت يعمل بنجاح!");
        };
      }
    },

    startListening: function () {
      this.isListening = true;
      this.updateStatus("listening");
      try {
        this.recognition.start();
      } catch (e) {
        this.isListening = false;
        this.updateStatus("idle");
      }
    },

    updateStatus: function (state) {
      var statusEl = document.getElementById("voice-status");
      var micBtn = document.getElementById("voice-mic-btn");

      if (!statusEl || !micBtn) return;

      micBtn.classList.remove("listening", "speaking");

      if (state === "listening") {
        statusEl.innerText = "🎧 أنا أستمع...";
        micBtn.classList.add("listening");
      } else if (state === "thinking") {
        statusEl.innerText = "🤔 دقيقة...";
      } else if (state === "speaking") {
        statusEl.innerText = "🗣️ أنا أتكلم...";
        micBtn.classList.add("speaking");
      } else {
        statusEl.innerText = "اضغط للتحدث";
      }
    },

    speak: function (text) {
      if (!this.synth) {
        console.error("Speech synthesis not supported");
        return;
      }

      this.synth.cancel();
      this.isSpeaking = true;
      this.updateStatus("speaking");

      var self = this;

      // Function to actually speak
      var doSpeak = function () {
        var msg = new SpeechSynthesisUtterance(text);
        var isArabic = /[\u0600-\u06FF]/.test(text);
        msg.lang = isArabic ? 'ar-SA' : 'en-US';
        msg.rate = 0.9;
        msg.pitch = 1.0;
        msg.volume = 1.0;

        var voices = self.synth.getVoices();
        console.log("Available voices:", voices.length);

        if (voices.length > 0) {
          if (isArabic) {
            msg.voice = voices.find(v => v.lang.includes('ar')) || voices[0];
          } else {
            msg.voice = voices.find(v => v.lang.includes('en')) || voices[0];
          }
        }

        msg.onstart = function () {
          console.log("Speech started:", text.substring(0, 50));
        };

        msg.onend = function () {
          console.log("Speech ended");
          self.isSpeaking = false;
          self.updateStatus("idle");
        };

        msg.onerror = function (e) {
          console.error("Speech error:", e);
          self.isSpeaking = false;
          self.updateStatus("idle");
        };

        self.synth.speak(msg);
      };

      // Wait for voices to load
      var voices = this.synth.getVoices();
      if (voices.length === 0) {
        console.log("Waiting for voices to load...");
        this.synth.onvoiceschanged = function () {
          console.log("Voices loaded!");
          doSpeak();
        };
      } else {
        doSpeak();
      }
    }
  };

  Store.load();
  function start() {
    Renderer.updateUI();
    VoiceBot.init();
  }
  if (document.readyState === 'complete') start();
  else window.onload = start;
})();