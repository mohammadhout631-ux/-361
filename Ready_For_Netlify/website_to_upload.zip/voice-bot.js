/**
 * AI Voice Waiter Bot
 * Bilingual (Arabic/English) natural conversation via Gemini AI
 */

const VoiceBot = {
    API_URL: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',

    recognition: null,
    synth: window.speechSynthesis,
    isListening: false,
    isSpeaking: false,

    getApiKey: function () {
        const data = RestaurantData.getData();
        return data.info.geminiKey || 'AIzaSyCbb3N0OXpBGcWXDvYNaOzyx8OPWd53MSc';
    },

    init: function () {
        if (document.getElementById('voice-bot-root')) return;

        // Setup UI
        const root = document.createElement('div');
        root.id = 'voice-bot-root';
        root.innerHTML = `
            <div id="voice-panel" style="display:none; position:fixed; bottom:100px; left:20px; width:320px; background:#1a1a1a; border:3px solid #f5e60d; border-radius:20px; z-index:99999; padding:20px; box-shadow:0 10px 40px rgba(0,0,0,0.8); font-family:sans-serif; direction:rtl;">
                <div style="text-align:center; margin-bottom:15px;">
                    <h3 style="color:#f5e60d; margin:0 0 5px 0;">🎙️ النادل الذكي</h3>
                    <small id="voice-status" style="color:#aaa;">اضغط للتحدث معي</small>
                    <div id="diag-info" style="font-size:10px; color:#555; margin-top:5px;"></div>
                </div>
                <div style="text-align:center; margin:20px 0;">
                    <button id="mic-btn" style="width:80px; height:80px; background:#f5e60d; border:none; border-radius:50%; font-size:35px; cursor:pointer; transition:0.3s; color:#000;">
                        <i class="fas fa-microphone"></i>
                    </button>
                    <div id="voice-wave" style="display:none; margin-top:15px; justify-content:center; gap:4px; height:20px;">
                        <span class="wave-bar"></span><span class="wave-bar"></span><span class="wave-bar"></span>
                    </div>
                </div>
                <div style="text-align:center; border-top:1px solid #333; padding-top:10px; margin-top:10px; display:flex; justify-content:space-around; flex-wrap:wrap; gap:5px;">
                    <button id="test-voice-btn" style="background:#444; color:white; border:none; padding:5px 12px; border-radius:8px; cursor:pointer; font-size:11px;"><i class="fas fa-volume-up"></i> اختبار الذكاء</button>
                    <button id="simple-speak-btn" style="background:#444; color:white; border:none; padding:5px 12px; border-radius:8px; cursor:pointer; font-size:11px;"><i class="fas fa-play"></i> فحص السماعة</button>
                    <a href="admin.html" style="color:var(--primary); text-decoration:none; font-size:11px; align-self:center;"><i class="fas fa-cog"></i> الإعدادات</a>
                </div>
            </div>
            <button id="voice-fab" style="position:fixed; bottom:20px; left:20px; width:65px; height:65px; background:#f5e60d; border:none; border-radius:50%; font-size:28px; cursor:pointer; z-index:100000; box-shadow:0 5px 20px rgba(245,230,13,0.5); transition:0.3s; color:#000;">
                <i class="fas fa-comment-dots"></i>
            </button>
            <style>
                .active-mic { background: #ff4757 !important; color: white !important; transform: scale(1.1); box-shadow: 0 0 20px rgba(255,71,87,0.6); }
                .wave-bar { width: 4px; height: 100%; background: var(--primary); animation: wave 1s infinite ease-in-out; }
                .wave-bar:nth-child(2) { animation-delay: 0.2s; }
                .wave-bar:nth-child(3) { animation-delay: 0.4s; }
                @keyframes wave { 0%, 100% { height: 5px; } 50% { height: 20px; } }
            </style>
        `;
        document.body.appendChild(root);

        // Events
        const fab = document.getElementById('voice-fab');
        const panel = document.getElementById('voice-panel');
        const micBtn = document.getElementById('mic-btn');
        const testBtn = document.getElementById('test-voice-btn');
        const simpleBtn = document.getElementById('simple-speak-btn');

        fab.onclick = () => {
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
            this.updateDiag();
        };

        micBtn.onclick = () => this.toggleListening();

        testBtn.onclick = () => {
            console.log("Manual voice test triggered");
            this.speak("مرحباً بك في مطعم الحوت. هل الصوت يعمل بشكل جيد؟");
        };

        simpleBtn.onclick = () => {
            console.log("Simple speak test");
            this.synth.cancel();
            const u = new SpeechSynthesisUtterance("Test 1 2 3. الصوت يعمل.");
            u.lang = 'ar-SA';
            this.synth.speak(u);
            alert("تم إرسال أمر الصوت الأساسي للمتصفح. هل سمعت شيئاً؟");
        };

        // Setup Speech
        const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (Speech) {
            this.recognition = new Speech();
            this.recognition.lang = 'ar-SA';
            this.recognition.onresult = (e) => this.handleResult(e);
            this.recognition.onend = () => this.stopListeningUI();
            this.recognition.onerror = () => this.stopListeningUI();
        }

        // Initialize voices list
        this.synth.onvoiceschanged = () => this.updateDiag();
        this.updateDiag();
    },

    updateDiag: function () {
        const diag = document.getElementById('diag-info');
        if (!diag) return;
        const voices = this.synth.getVoices();
        const ar = voices.filter(v => v.lang.includes('ar')).length;
        diag.innerText = `Voices: ${voices.length} | Arabic: ${ar}`;
    },

    toggleListening: function () {
        if (!this.recognition) return alert('متصفحك لا يدعم التعرف على الصوت');
        if (this.isListening) {
            this.recognition.stop();
        } else {
            this.startListeningUI();
            this.recognition.start();
        }
    },

    startListeningUI: function () {
        this.isListening = true;
        document.getElementById('mic-btn').classList.add('active-mic');
        document.getElementById('voice-status').innerText = 'أنا أسمعك...';
    },

    stopListeningUI: function () {
        this.isListening = false;
        document.getElementById('mic-btn').classList.remove('active-mic');
        document.getElementById('voice-status').innerText = 'اضغط للتحدث';
    },

    handleResult: async function (event) {
        const text = event.results[0][0].transcript;
        document.getElementById('voice-status').innerText = 'دقيقة، أفكر...';

        const data = RestaurantData.getData();
        const response = await this.askAI(text, data);
        this.speak(response);
    },

    askAI: async function (userText, data) {
        // Build the system prompt
        let menuStr = "";
        data.categories.forEach(cat => {
            const items = data.items.filter(i => i.categoryId === cat.id);
            menuStr += `\n${cat.name}:\n` + items.map(i => `- ${i.name}: ${i.price} $`).join('\n');
        });

        const prompt = `أنت "النادل الذكي" لـ ${data.info.name}.
        المعلومات: الهاتف ${data.info.phone}، العنوان ${data.info.address}، ساعات العمل ${data.info.openHours}.
        المنيو: ${menuStr}
        
        تعليماتك:
        - تكلم بلهجة لبنانية ودودة ومحترفة.
        - ساعد الزبون وبِعْ له أطباقنا (upselling).
        - إذا سأل عن شيء غير موجود، اقترح بدائل.
        - رد بنفس لغة الزبون.
        - كن مختصراً ولبقاً.
        
        سؤال الزبون: ${userText}`;

        try {
            const key = this.getApiKey();
            const res = await fetch(`${this.API_URL}?key=${key}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: { temperature: 0.7, maxOutputTokens: 200 }
                })
            });
            const d = await res.json();

            if (d.error) {
                console.error("Gemini API Error Object:", d.error);
                if (d.error.status === "PERMISSION_DENIED" || d.error.status === "UNAUTHENTICATED") {
                    return "عذراً، يبدو أن مفتاح الـ API غير صالح أو انتهت صلاحيته. يرجى تحديثه من لوحة التحكم.";
                }
                return `عذراً، حدث خطأ في النظام: ${d.error.message || 'خطأ مجهول'}`;
            }

            if (!d.candidates || d.candidates.length === 0) {
                return "عذراً، لم أستطع فهم ذلك بشكل صحيح. هل يمكنك الإعادة؟";
            }

            return d.candidates[0].content.parts[0].text;
        } catch (e) {
            console.error("AI Error:", e);
            return "عذراً، فشلت في الاتصال بالذكاء الاصطناعي. تأكد من اتصالك بالإنترنت.";
        }
    },

    speak: function (text) {
        console.log("Speaking:", text);
        this.synth.cancel();

        // Wake up synth for some browsers
        this.synth.speak(new SpeechSynthesisUtterance(""));

        const utterance = new SpeechSynthesisUtterance(text);
        const isArabic = /[\u0600-\u06FF]/.test(text);
        utterance.lang = isArabic ? 'ar-SA' : 'en-US';
        utterance.rate = 0.9;
        utterance.pitch = 1.0;

        const doSpeak = () => {
            const voices = this.synth.getVoices();
            console.log("Available voices count:", voices.length);

            if (isArabic) {
                // Try to find a good Arabic voice
                utterance.voice = voices.find(v => v.lang.includes('ar-SA')) ||
                    voices.find(v => v.lang.includes('ar')) ||
                    voices[0];
            } else {
                utterance.voice = voices.find(v => v.lang.includes('en-US')) ||
                    voices.find(v => v.lang.includes('en')) ||
                    voices[0];
            }

            console.log("Selected voice:", utterance.voice ? utterance.voice.name : "Default");

            utterance.onstart = () => {
                console.log("Speech started");
                document.getElementById('voice-status').innerText = 'أنا أتحدث الآن...';
                document.getElementById('voice-wave').style.display = 'flex';
            };

            utterance.onend = () => {
                console.log("Speech ended");
                document.getElementById('voice-status').innerText = 'اضغط للتحدث';
                document.getElementById('voice-wave').style.display = 'none';
            };

            utterance.onerror = (err) => {
                console.error("Speech error:", err);
            };

            this.synth.speak(utterance);
        };

        if (this.synth.getVoices().length === 0) {
            console.log("Voices not loaded, waiting...");
            this.synth.onvoiceschanged = () => {
                console.log("Voices loaded successfully!");
                doSpeak();
            };
            // Backup timeout in case onvoiceschanged doesn't fire
            setTimeout(doSpeak, 1000);
        } else {
            doSpeak();
        }
    }
};

// Initialize
VoiceBot.init();
