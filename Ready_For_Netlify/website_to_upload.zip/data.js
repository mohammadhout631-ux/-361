/**
 * Restaurant Data Management System
 * Handles all menu data with localStorage persistence
 */

const RestaurantData = (function () {
    const STORAGE_KEY = 'al_hout_restaurant_data';

    // Default data
    const DEFAULT_DATA = {
        info: {
            name: "مطعم الحوت | Al-Hout Restaurant",
            phone: "03 631 903",
            address: "Bhamdoun Al Day3a - بحمدون الضيعة",
            currency: "$",
            openHours: "12:00 PM - 12:00 AM",
            adminPassword: "1234",
            geminiKey: "AIzaSyCbb3N0OXpBGcWXDvYNaOzyx8OPWd53MSc"
        },
        categories: [
            { id: "c_1", name: "حلويات", order: 1 },
            { id: "c_2", name: "مناقيش صاج", order: 2 },
            { id: "c_3", name: "أطباق رئيسية", order: 3 },
            { id: "c_4", name: "مقبلات", order: 4 },
            { id: "c_5", name: "لقمشات ومقرمشات", order: 5 },
            { id: "c_6", name: "مشروبات ساخنة", order: 6 },
            { id: "c_7", name: "مشروبات باردة", order: 7 },
            { id: "c_8", name: "مشروبات كوكتال وعصائر طازجة", order: 8 },
            { id: "c_9", name: "أراكيل", order: 9 }
        ],
        items: [
            // حلويات
            { id: "i_1", categoryId: "c_1", name: "ليزي كيك", price: "6", image: "" },
            { id: "i_2", categoryId: "c_1", name: "بوظة دق مع غزل البنات", price: "10", image: "" },

            // مناقيش صاج
            { id: "i_3", categoryId: "c_2", name: "زعتر", price: "2", image: "" },
            { id: "i_4", categoryId: "c_2", name: "جبنة", price: "4", image: "" },
            { id: "i_5", categoryId: "c_2", name: "زعتر ولبنة", price: "3", image: "" },
            { id: "i_6", categoryId: "c_2", name: "لبنة", price: "3", image: "" },
            { id: "i_7", categoryId: "c_2", name: "كشك", price: "3", image: "" },
            { id: "i_8", categoryId: "c_2", name: "كشك وجبنة", price: "4", image: "" },
            { id: "i_9", categoryId: "c_2", name: "محمره", price: "3", image: "" },
            { id: "i_10", categoryId: "c_2", name: "محمره بالجبنة", price: "4", image: "" },
            { id: "i_11", categoryId: "c_2", name: "بندورة وبصل", price: "3", image: "" },
            { id: "i_12", categoryId: "c_2", name: "بندورة وبصل وجبنة", price: "4", image: "" },
            { id: "i_13", categoryId: "c_2", name: "سجق وجبنة", price: "7", image: "" },
            { id: "i_14", categoryId: "c_2", name: "حبش وجبنة", price: "7", image: "" },
            { id: "i_15", categoryId: "c_2", name: "جبنة مكس", price: "5", image: "" },
            { id: "i_16", categoryId: "c_2", name: "كوكتيل زعتر وجبنة", price: "4", image: "" },
            { id: "i_17", categoryId: "c_2", name: "بيتزا مارغريتا", price: "6", image: "" },
            { id: "i_18", categoryId: "c_2", name: "بيتزا حبش", price: "8", image: "" },
            { id: "i_19", categoryId: "c_2", name: "بيتزا خضار", price: "8", image: "" },
            { id: "i_20", categoryId: "c_2", name: "نوتيلا", price: "5", image: "" },
            { id: "i_21", categoryId: "c_2", name: "رغيف صباح", price: "0.5", image: "" },

            // أطباق رئيسية
            { id: "i_22", categoryId: "c_3", name: "صحن برغر لحمة", price: "10", image: "" },
            { id: "i_23", categoryId: "c_3", name: "صحن برغر دجاج", price: "8", image: "" },
            { id: "i_24", categoryId: "c_3", name: "صحن طاووق", price: "8", image: "" },
            { id: "i_25", categoryId: "c_3", name: "صحن اسكلوب", price: "8", image: "" },
            { id: "i_26", categoryId: "c_3", name: "سفاين دجاج", price: "10", image: "" },
            { id: "i_27", categoryId: "c_3", name: "صحن ناغتس", price: "6", image: "" },
            { id: "i_28", categoryId: "c_3", name: "صحن بطاطا", price: "4", image: "" },
            { id: "i_29", categoryId: "c_3", name: "صحن بطاطا ودجيز", price: "4", image: "" },

            // مقبلات
            { id: "i_30", categoryId: "c_4", name: "صحن حمص", price: "4", image: "" },
            { id: "i_31", categoryId: "c_4", name: "صحن متبل بازنجان", price: "4", image: "" },
            { id: "i_32", categoryId: "c_4", name: "صحن خضار", price: "4", image: "" },
            { id: "i_33", categoryId: "c_4", name: "صحن فتوش", price: "7", image: "" },
            { id: "i_34", categoryId: "c_4", name: "صحن لبنة", price: "6", image: "" },
            { id: "i_35", categoryId: "c_4", name: "صحن لبنة مع ثوم", price: "7", image: "" },
            { id: "i_36", categoryId: "c_4", name: "صحن بيض", price: "6", image: "" },
            { id: "i_37", categoryId: "c_4", name: "صحن بيض مع سجق", price: "10", image: "" },
            { id: "i_38", categoryId: "c_4", name: "صحن مكدوس", price: "6", image: "" },
            { id: "i_39", categoryId: "c_4", name: "سلطة سيزر", price: "12", image: "" },
            { id: "i_40", categoryId: "c_4", name: "بطاطا مشوية", price: "7", image: "" },

            // لقمشات ومقرمشات
            { id: "i_41", categoryId: "c_5", name: "تشبس", price: "2", image: "" },
            { id: "i_42", categoryId: "c_5", name: "بوشار", price: "3", image: "" },
            { id: "i_43", categoryId: "c_5", name: "جزر", price: "4", image: "" },
            { id: "i_44", categoryId: "c_5", name: "بزورات", price: "4", image: "" },
            { id: "i_45", categoryId: "c_5", name: "ترمس", price: "4", image: "" },
            { id: "i_46", categoryId: "c_5", name: "ترمس وجزر", price: "5", image: "" },
            { id: "i_47", categoryId: "c_5", name: "حامض وجزر", price: "5", image: "" },
            { id: "i_48", categoryId: "c_5", name: "حامض وجزر وترمس", price: "6", image: "" },
            { id: "i_49", categoryId: "c_5", name: "ذرة وحامض", price: "5", image: "" },
            { id: "i_50", categoryId: "c_5", name: "ذرة وجبنة", price: "6", image: "" },
            { id: "i_51", categoryId: "c_5", name: "قلوبات", price: "7", image: "" },
            { id: "i_52", categoryId: "c_5", name: "ادمامي", price: "7", image: "" },

            // مشروبات ساخنة
            { id: "i_53", categoryId: "c_6", name: "قهوة تركية", price: "2", image: "" },
            { id: "i_54", categoryId: "c_6", name: "قهوة اكسبريسو", price: "2", image: "" },
            { id: "i_55", categoryId: "c_6", name: "قهوة بيضاء", price: "2", image: "" },
            { id: "i_56", categoryId: "c_6", name: "نسكافيه", price: "3", image: "" },
            { id: "i_57", categoryId: "c_6", name: "كابتشينو", price: "3", image: "" },
            { id: "i_58", categoryId: "c_6", name: "شاي", price: "3", image: "" },
            { id: "i_59", categoryId: "c_6", name: "شاي أخضر", price: "3", image: "" },
            { id: "i_60", categoryId: "c_6", name: "كمون", price: "3", image: "" },
            { id: "i_61", categoryId: "c_6", name: "زنجبيل وعسل", price: "3", image: "" },
            { id: "i_62", categoryId: "c_6", name: "نعناع", price: "3", image: "" },
            { id: "i_63", categoryId: "c_6", name: "زهورات", price: "3", image: "" },
            { id: "i_64", categoryId: "c_6", name: "بابونج", price: "3", image: "" },
            { id: "i_65", categoryId: "c_6", name: "يانسون", price: "3", image: "" },
            { id: "i_66", categoryId: "c_6", name: "كانارينو", price: "2", image: "" },
            { id: "i_67", categoryId: "c_6", name: "هوت شوكلت", price: "5", image: "" },
            { id: "i_68", categoryId: "c_6", name: "سحلب", price: "4", image: "" },

            // مشروبات باردة
            { id: "i_69", categoryId: "c_7", name: "دارك بلو", price: "4", image: "" },
            { id: "i_70", categoryId: "c_7", name: "بوم بوم", price: "5", image: "" },
            { id: "i_71", categoryId: "c_7", name: "بيبسي", price: "2", image: "" },
            { id: "i_72", categoryId: "c_7", name: "سفن أب", price: "2", image: "" },
            { id: "i_73", categoryId: "c_7", name: "ميرندا", price: "2", image: "" },
            { id: "i_74", categoryId: "c_7", name: "آيس تي", price: "3", image: "" },
            { id: "i_75", categoryId: "c_7", name: "ليزرة", price: "4", image: "" },
            { id: "i_76", categoryId: "c_7", name: "ليزرة مكس كن", price: "5", image: "" },
            { id: "i_77", categoryId: "c_7", name: "غرانادين أو هواي", price: "1", image: "" },
            { id: "i_78", categoryId: "c_7", name: "الوافيرا", price: "7", image: "" },
            { id: "i_79", categoryId: "c_7", name: "آيس كوفي", price: "5", image: "" },

            // مشروبات كوكتال وعصائر طازجة
            { id: "i_80", categoryId: "c_8", name: "فريرز", price: "6", image: "" },
            { id: "i_81", categoryId: "c_8", name: "مانغا", price: "6", image: "" },
            { id: "i_82", categoryId: "c_8", name: "ليموناضة", price: "5", image: "" },
            { id: "i_83", categoryId: "c_8", name: "ليموناضة بالنعناع", price: "5", image: "" },
            { id: "i_84", categoryId: "c_8", name: "ليمون", price: "5", image: "" },
            { id: "i_85", categoryId: "c_8", name: "كوكتال", price: "7", image: "" },
            { id: "i_86", categoryId: "c_8", name: "ميلك شيك فراولة", price: "7", image: "" },
            { id: "i_87", categoryId: "c_8", name: "ميلك شيك شوكولاتة", price: "7", image: "" },
            { id: "i_88", categoryId: "c_8", name: "موز وفرازة", price: "6", image: "" },
            { id: "i_89", categoryId: "c_8", name: "حليب وموز", price: "6", image: "" },
            { id: "i_90", categoryId: "c_8", name: "ميلك شيك كراميل", price: "7", image: "" },
            { id: "i_91", categoryId: "c_8", name: "ماء كبير", price: "2", image: "" },
            { id: "i_92", categoryId: "c_8", name: "ماء صغير", price: "1", image: "" },
            { id: "i_93", categoryId: "c_8", name: "كوب ثلج", price: "1", image: "" },
            { id: "i_94", categoryId: "c_8", name: "ماء غازية", price: "3", image: "" },

            // أراكيل
            { id: "i_95", categoryId: "c_9", name: "تفاحتين", price: "10", image: "" },
            { id: "i_96", categoryId: "c_9", name: "حامض ونعناع", price: "10", image: "" },
            { id: "i_97", categoryId: "c_9", name: "عنب", price: "10", image: "" },
            { id: "i_98", categoryId: "c_9", name: "عنب ونعناع", price: "10", image: "" },
            { id: "i_99", categoryId: "c_9", name: "عجمي", price: "10", image: "" },
            { id: "i_100", categoryId: "c_9", name: "نكهة", price: "8", image: "" },
            { id: "i_101", categoryId: "c_9", name: "فرش", price: "15", image: "" },
            { id: "i_102", categoryId: "c_9", name: "نريش بلاستيك", price: "2", image: "" }
        ]
    };

    // Load data from localStorage or use default
    function loadData() {
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (!stored) return DEFAULT_DATA;

            const parsed = JSON.parse(stored);
            // Merge with DEFAULT_DATA to ensure new fields (like geminiKey) exist
            return {
                ...DEFAULT_DATA,
                ...parsed,
                info: { ...DEFAULT_DATA.info, ...parsed.info }
            };
        } catch (e) {
            console.error('Error loading data:', e);
            return DEFAULT_DATA;
        }
    }

    // Save data to localStorage
    function saveData(data) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
            return true;
        } catch (e) {
            console.error('Error saving data:', e);
            return false;
        }
    }

    // Public API
    return {
        getData: loadData,
        saveData: saveData,
        resetData: () => {
            saveData(DEFAULT_DATA);
            return DEFAULT_DATA;
        },
        exportData: () => {
            return JSON.stringify(loadData(), null, 2);
        },
        importData: (jsonString) => {
            try {
                const data = JSON.parse(jsonString);
                saveData(data);
                return true;
            } catch (e) {
                console.error('Error importing data:', e);
                return false;
            }
        }
    };
})();
