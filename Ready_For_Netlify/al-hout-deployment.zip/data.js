/**
 * Restaurant Data Management System
 * Handles all menu data with localStorage persistence
 */

const RestaurantData = (function () {
    const DB_NAME = 'AlHoutRestaurantDB';
    const DB_VERSION = 1;
    const STORE_NAME = 'restaurant_data';
    const STORAGE_KEY = 'al_hout_restaurant_data'; // Legacay key for migration

    // Default data (kept for first-time init)
    const DEFAULT_DATA = {
        info: {
            name: "مطعم الحوت | Al-Hout Restaurant",
            phone: "03 631 903",
            address: "Bhamdoun Al Day3a - بحمدون الضيعة",
            currency: "$",
            openHours: "12:00 PM - 12:00 AM",
            adminPassword: "1234",

            logo: { image: "", text: "مطعم الحوت 🐋" },
            dailyDish: {
                active: false,
                title: "طبق اليوم",
                text: "وصف طبق اليوم المميز...",
                image: "",
                video: ""
            }
        },
        categories: [
            { id: "c_1", name: "حلويات", order: 1, image: "" },
            { id: "c_2", name: "مناقيش صاج", order: 2, image: "" },
            { id: "c_3", name: "أطباق رئيسية", order: 3, image: "" },
            { id: "c_4", name: "مقبلات", order: 4, image: "" },
            { id: "c_5", name: "لقمشات ومقرمشات", order: 5, image: "" },
            { id: "c_6", name: "مشروبات ساخنة", order: 6, image: "" },
            { id: "c_7", name: "مشروبات باردة", order: 7, image: "" },
            { id: "c_8", name: "مشروبات كوكتال وعصائر طازجة", order: 8, image: "" },
            { id: "c_9", name: "أراكيل", order: 9, image: "" }
        ],
        items: [
            { id: "i_1", categoryId: "c_1", name: "ليزي كيك", price: "6", description: "", image: "" },
            { id: "i_2", categoryId: "c_1", name: "بوظة دق مع غزل البنات", price: "10", description: "", image: "" },
            { id: "i_3", categoryId: "c_2", name: "زعتر", price: "2", description: "", image: "" },
            { id: "i_4", categoryId: "c_2", name: "جبنة", price: "4", description: "", image: "" },
            { id: "i_5", categoryId: "c_2", name: "زعتر ولبنة", price: "3", description: "", image: "" },
            { id: "i_6", categoryId: "c_3", name: "رز", price: "2", description: "أرز بسمتي مفلفل", image: "" },
            { id: "i_7", categoryId: "c_7", name: "مياه معدنية", price: "1", description: "", image: "" },
            { id: "i_102", categoryId: "c_9", name: "نريش بلاستيك", price: "2", description: "", image: "" }
        ]
    };

    function openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    db.createObjectStore(STORE_NAME);
                }
            };
        });
    }

    async function ensureInitialized() {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const data = await new Promise(r => {
            const req = store.get('all_data');
            req.onsuccess = () => r(req.result);
        });

        if (!data) {
            // Check legacy localStorage for migration
            const legacy = localStorage.getItem(STORAGE_KEY);
            if (legacy) {
                try {
                    const parsed = JSON.parse(legacy);
                    await saveData(parsed);
                    console.log('Migration from localStorage successful');
                } catch (e) {
                    await saveData(DEFAULT_DATA);
                }
            } else {
                await saveData(DEFAULT_DATA);
            }
        }
    }

    async function loadData() {
        await ensureInitialized();
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        return new Promise((resolve, reject) => {
            const request = store.get('all_data');
            request.onsuccess = () => {
                const parsed = request.result;
                // Basic deep merge for safety
                const info = {
                    ...DEFAULT_DATA.info,
                    ...parsed.info,
                    logo: { ...DEFAULT_DATA.info.logo, ...(parsed.info ? parsed.info.logo : {}) },
                    dailyDish: { ...DEFAULT_DATA.info.dailyDish, ...(parsed.info ? parsed.info.dailyDish : {}) }
                };
                resolve({ ...DEFAULT_DATA, ...parsed, info: info });
            };
            request.onerror = () => reject(request.error);
        });
    }

    async function saveData(data) {
        // Validation/Cleanup
        if (data.items) {
            data.items.forEach(item => {
                if (item.description === undefined) item.description = "";
            });
        }
        if (data.categories) {
            data.categories.forEach(cat => {
                if (cat.image === undefined) cat.image = "";
            });
        }

        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        return new Promise((resolve, reject) => {
            const request = store.put(data, 'all_data');
            request.onsuccess = () => resolve(true);
            request.onerror = () => {
                console.error('IDB Save Error:', request.error);
                alert('❌ فشل حفظ البيانات في قاعدة البيانات!');
                resolve(false);
            };
        });
    }

    return {
        getData: loadData,
        saveData: saveData,
        resetData: async () => {
            await saveData(DEFAULT_DATA);
            return DEFAULT_DATA;
        },
        exportData: async () => {
            const d = await loadData();
            return JSON.stringify(d, null, 2);
        },
        importData: async (jsonString) => {
            try {
                const data = JSON.parse(jsonString);
                return await saveData(data);
            } catch (e) {
                console.error('Error importing data:', e);
                return false;
            }
        }
    };
})();
