/**
 * Al-Hout Restaurant | Royal Lebanese Waiter (v14)
 * Strict Persona | Order, Bill, Complaint Logic
 */

const VoiceWaiter = {
    // Config
    TELEGRAM_BOT_TOKEN: '8371588532:AAGNQ8U_i3insICuGQ6-2XFb2-OwDiHDjfE',
    TELEGRAM_GROUP_ID: '-1003610965844',

    state: 'IDLE', // IDLE, ASKING_ORDER, ASKING_TABLE, ASKING_BILL_TABLE, ASKING_COMPLAINT_TABLE
    currentTable: '',
    allDetectedItems: [], // {name, qty, price}
    lastComplaint: '',

    recognition: null,
    synth: window.speechSynthesis,
    isListening: false,
    menuItems: [],
    audioUnlocked: false,

    init: async function () {
        try {
            console.log("VoiceWaiter: Initializing Refactor (v14)...");
            this.setupRecognition();
            this.renderUI();
            this.setupListeners();
            await this.loadMenu();
            this.preloadVoices();
        } catch (e) {
            console.error("VoiceWaiter Init Error:", e);
        }
    },

    preloadVoices: function () {
        const load = () => { if (this.synth.getVoices().length > 0) console.log("Voices Ready"); };
        load();
        if (this.synth.onvoiceschanged !== undefined) this.synth.onvoiceschanged = load;
    },

    loadMenu: async function () {
        try {
            const data = await RestaurantData.getData();
            this.menuItems = (data.items || []).sort((a, b) => b.name.length - a.name.length);
        } catch (e) { console.error(e); }
    },

    setupRecognition: function () {
        const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!Speech) return;
        this.recognition = new Speech();
        this.recognition.lang = 'ar-SA';
        this.recognition.continuous = true;
        this.recognition.interimResults = false;

        this.recognition.onstart = () => {
            this.isListening = true;
            document.getElementById('voice-mic-btn').classList.add('recording');
        };

        this.recognition.onresult = (e) => {
            const transcript = e.results[e.results.length - 1][0].transcript;
            this.handleInput(transcript);
        };

        this.recognition.onend = () => {
            this.isListening = false;
            document.getElementById('voice-mic-btn').classList.remove('recording');
            const isVisible = document.getElementById('voice-waiter-overlay') && document.getElementById('voice-waiter-overlay').style.display === 'flex';
            if (isVisible && this.state !== 'IDLE') {
                setTimeout(() => {
                    try { if (!this.isListening) this.recognition.start(); } catch (e) { }
                }, 300);
            }
        };

        this.recognition.onerror = () => { this.isListening = false; };
    },

    renderUI: function () {
        if (document.getElementById('voice-waiter-overlay')) return;
        const overlay = document.createElement('div');
        overlay.id = 'voice-waiter-overlay';
        overlay.innerHTML = `
            <div class="luxury-card">
                <div class="luxury-header">
                    <span class="luxury-title">نادل مطعم الحوت 🍽</span>
                    <i class="fas fa-times" id="close-waiter" style="cursor:pointer; color:#d4af37;"></i>
                </div>
                <div class="luxury-body">
                    <div id="waiter-status">تفضل، شو بتحب تطلب؟ ✨</div>
                    
                    <div id="luxury-invoice-container" style="display:none;">
                        <div class="lux-paper">
                            <div class="lux-store-name">طلبك 🧾</div>
                            <div class="lux-divider"></div>
                            <table class="lux-table">
                                <tbody id="lux-items-body"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="waiter-actions">
                        <div class="mic-wrapper">
                            <button id="voice-mic-btn"><i class="fas fa-microphone"></i></button>
                            <div class="speaking-indicator" id="speak-ind">
                                <span></span><span></span><span></span>
                            </div>
                        </div>
                        <div class="lux-input-box">
                            <textarea id="waiter-text" placeholder="اكتب طلبك أو مشكلتك هنا..." rows="2"></textarea>
                            <div class="input-btns">
                                <button id="send-btn" title="إرسال"><i class="fas fa-paper-plane"></i></button>
                                <button id="bill-btn" title="طلب الفاتورة"><i class="fas fa-file-invoice-dollar"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                #voice-waiter-overlay {
                    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                    background: rgba(0,0,0,0.9); z-index: 9999; display: none; align-items: center; justify-content: center; backdrop-filter: blur(10px);
                }
                .luxury-card {
                    background: #111; border: 1px solid #d4af37; width: 90%; max-width: 400px;
                    border-radius: 30px; overflow: hidden; box-shadow: 0 40px 100px rgba(0,0,0,0.5);
                }
                .luxury-header { background: #000; color: #d4af37; padding: 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #d4af37; }
                .luxury-title { font-weight: bold; font-size: 1.2em; }
                .luxury-body { padding: 30px 20px; color: white; text-align: center; }
                #waiter-status { font-size: 1.3em; margin-bottom: 20px; line-height: 1.5; min-height: 60px; }
                #luxury-invoice-container { margin-bottom: 20px; animation: luxSlideUp 0.5s; }
                .lux-paper { background: #fff; color: #111; padding: 20px; border-radius: 15px; text-align: right; direction: rtl; }
                .lux-store-name { font-weight: bold; font-size: 1.1em; text-align: center; }
                .lux-divider { height: 1px; background: #ddd; margin: 10px 0; }
                .lux-table { width: 100%; border-collapse: collapse; }
                .lux-table td { padding: 8px 0; border-bottom: 1px solid #eee; }
                .waiter-actions { display: flex; flex-direction: column; gap: 20px; align-items: center; }
                #voice-mic-btn { width: 70px; height: 70px; border-radius: 50%; background: #d4af37; border: none; font-size: 25px; cursor: pointer; color: #000; }
                #voice-mic-btn.recording { animation: pulseV14 1s infinite alternate; }
                .speaking-indicator { display: none; margin-top: 10px; gap: 5px; justify-content: center; }
                .speaking-indicator span { width: 8px; height: 8px; background: #d4af37; border-radius: 50%; animation: bounceV14 0.5s infinite alternate; }
                .speaking-indicator span:nth-child(2) { animation-delay: 0.1s; }
                .speaking-indicator span:nth-child(3) { animation-delay: 0.2s; }
                @keyframes bounceV14 { to { transform: translateY(-10px); } }
                @keyframes pulseV14 { from { box-shadow: 0 0 10px #d4af37; } to { box-shadow: 0 0 30px #d4af37; } }
                @keyframes luxSlideUp { from { opacity:0; transform: translateY(20px); } to { opacity:1; transform: translateY(0); } }
                .lux-input-box { display: flex; width: 100%; background: #222; border-radius: 20px; padding: 10px 15px; border: 1px solid #444; align-items: center; gap: 10px; }
                #waiter-text { flex: 1; background: transparent; border: none; color: white; outline: none; resize: none; direction: rtl; font-size: 16px; font-family: inherit; }
                .input-btns { display: flex; gap: 10px; }
                #send-btn, #bill-btn { background: #d4af37; border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; color: #000; transition: 0.3s; }
                #bill-btn { background: #fff; }
                #send-btn:hover, #bill-btn:hover { transform: scale(1.1); }
            </style>
        `;
        document.body.appendChild(overlay);
    },

    setupListeners: function () {
        document.querySelectorAll('.btn-whatsapp, #whatsapp-btn').forEach(b => {
            b.onclick = (e) => { e.preventDefault(); this.open(); };
        });
        document.getElementById('close-waiter').onclick = () => this.close();
        document.getElementById('voice-mic-btn').onclick = () => {
            if (this.isListening) this.recognition.stop(); else this.recognition.start();
        };
        const handleSend = () => {
            const t = document.getElementById('waiter-text').value.trim();
            if (t) { document.getElementById('waiter-text').value = ''; this.handleInput(t); }
        };
        document.getElementById('send-btn').onclick = handleSend;
        document.getElementById('bill-btn').onclick = () => this.handleInput("فاتورة");
        document.getElementById('waiter-text').onkeypress = (e) => { if (e.key === 'Enter') { e.preventDefault(); handleSend(); } };
    },

    open: function () {
        this.resetState();
        document.getElementById('voice-waiter-overlay').style.display = 'flex';
        if (!this.audioUnlocked) {
            const silent = new SpeechSynthesisUtterance(" ");
            silent.volume = 0;
            this.synth.speak(silent);
            this.audioUnlocked = true;
        }
        setTimeout(() => this.speak("أهلاً بك.. تفضل، شو الحابب تطلبه اليوم؟"), 500);
    },

    resetState: function () {
        this.state = 'ASKING_ORDER';
        this.allDetectedItems = [];
        this.currentTable = '';
        this.lastComplaint = '';
        document.getElementById('luxury-invoice-container').style.display = 'none';
        document.getElementById('waiter-status').innerText = "تفضل، شو بتحب تطلب؟ ✨";
    },

    close: function () {
        document.getElementById('voice-waiter-overlay').style.display = 'none';
        this.state = 'IDLE';
        if (this.recognition) this.recognition.stop();
        this.synth.cancel();
    },

    speak: function (text) {
        if (!this.synth) return;
        this.synth.cancel();
        const u = new SpeechSynthesisUtterance(text);
        const voices = this.synth.getVoices();
        let ar = voices.find(v => v.lang.includes('ar'));
        if (ar) u.voice = ar;
        u.lang = 'ar-SA';
        u.onstart = () => { document.getElementById('speak-ind').style.display = 'flex'; };
        u.onend = () => { document.getElementById('speak-ind').style.display = 'none'; };
        this.synth.speak(u);
    },

    handleInput: function (text) {
        if (!text) return;
        const low = text.toLowerCase().trim();

        // Check if there are menu items in the text regardless of state (unless giving table)
        const foundCount = this.scanItems(text);

        // 1. Complaint Check
        const complaintKeywords = ['late', 'missing', 'wrong', 'delay', 'تأخر', 'وين طلبي', 'نسيتوا', 'مشكلة', 'متاخر', 'غلط', 'problem'];
        const isComplaint = complaintKeywords.some(k => low.includes(k));

        // 2. Bill Check
        const billKeywords = ['فاتورة', 'فاتوره', 'الحساب', 'حساب', 'bill', 'invoice', 'check', 'خلاص'];
        const isAskingBill = billKeywords.some(k => low.includes(k));

        // Flow Override for status items
        if (isComplaint && this.state !== 'ASKING_COMPLAINT_TABLE') {
            this.lastComplaint = text;
            this.state = 'ASKING_COMPLAINT_TABLE';
            this.speak("بعتذر منك.. شو رقم الطاولة لتابع الموضوع فوراً؟");
            document.getElementById('waiter-status').innerText = "شو رقم الطاولة؟ 🪑";
            return;
        }

        if (isAskingBill && this.state !== 'ASKING_BILL_TABLE') {
            this.state = 'ASKING_BILL_TABLE';
            this.speak("حاضر، شو رقم الطاولة؟");
            document.getElementById('waiter-status').innerText = "شو رقم الطاولة؟ 🪑";
            return;
        }

        switch (this.state) {
            case 'ASKING_ORDER':
                if (foundCount > 0) {
                    const itemNames = this.allDetectedItems.map(i => `${i.qty} ${i.name}`).join(' و ');
                    this.speak(`تمام 👌 خليني أتأكد من طلبك: ${itemNames}... شو رقم الطاولة؟`);
                    document.getElementById('waiter-status').innerText = "شو رقم الطاولة؟ 🪑";
                    this.renderInvoice();
                    this.state = 'ASKING_TABLE';
                } else if (!isComplaint && !isAskingBill) {
                    this.speak("تفضل، شو بتحب تطلب؟ أنا عم أسمعك");
                }
                break;

            case 'ASKING_TABLE':
                const tNum = this.extractTableNumber(text);
                if (tNum) {
                    this.currentTable = tNum;
                    this.report('ORDER');
                    this.speak("تم إرسال طلبك للمطبخ 🍽");
                    document.getElementById('waiter-status').innerText = "تم الإرسال بنجاح ✅";
                    setTimeout(() => this.close(), 4000);
                } else {
                    this.speak("ما سمعت رقم الطاولة، أي طاولة قاعدين؟");
                }
                break;

            case 'ASKING_BILL_TABLE':
                const bTable = this.extractTableNumber(text);
                if (bTable) {
                    this.currentTable = bTable;
                    this.report('BILL');
                    this.speak("طلب الفاتورة وصل للإدارة");
                    document.getElementById('waiter-status').innerText = "طلب الفاتورة وصل ✅";
                    setTimeout(() => this.close(), 4000);
                } else {
                    this.speak("رقم الطاولة لو سمحت؟");
                }
                break;

            case 'ASKING_COMPLAINT_TABLE':
                const cTable = this.extractTableNumber(text);
                if (cTable) {
                    this.currentTable = cTable;
                    this.report('COMPLAINT');
                    this.speak("تم إبلاغ الإدارة فوراً");
                    document.getElementById('waiter-status').innerText = "تم إبلاغ الإدارة فوراً ✅";
                    setTimeout(() => this.close(), 4000);
                } else {
                    this.speak("رقم الطاولة كرمال نصلح الغلط؟");
                }
                break;
        }
    },

    scanItems: function (text) {
        let count = 0;
        let workingText = text.toLowerCase();
        const numMap = { 'واحد': 1, 'اتنين': 2, 'تنين': 2, 'تلاتة': 3, 'تلاته': 3, 'اربعة': 4, 'خمسة': 5, 'ستة': 6, 'سبعة': 7, 'تمانية': 8, 'تسعة': 9, 'عشرة': 10 };

        this.menuItems.forEach(item => {
            const name = item.name.toLowerCase();
            let index = workingText.indexOf(name);
            while (index !== -1) {
                // Look for quantity prefix in a 15-char window before the item name
                let windowText = workingText.substring(Math.max(0, index - 15), index);
                let qty = 1;
                const digitMatch = windowText.match(/(\d+)/);
                if (digitMatch) {
                    qty = parseInt(digitMatch[1]);
                } else {
                    for (let key in numMap) { if (windowText.includes(key)) { qty = numMap[key]; break; } }
                }

                this.allDetectedItems.push({ name: item.name, qty, price: item.price });
                count++;

                // Remove the matched instance to avoid double counting
                workingText = workingText.substring(0, index) + " ".repeat(name.length) + workingText.substring(index + name.length);
                index = workingText.indexOf(name);
            }
        });
        return count;
    },

    extractTableNumber: function (text) {
        const match = text.match(/\d+/);
        return match ? match[0] : null;
    },

    renderInvoice: function () {
        const body = document.getElementById('lux-items-body');
        document.getElementById('luxury-invoice-container').style.display = 'block';
        body.innerHTML = this.allDetectedItems.map(i => `<tr><td>${i.name}</td><td>x${i.qty}</td></tr>`).join('');
    },

    report: function (type) {
        let payload = {};
        if (type === 'ORDER') {
            let total = 0;
            const items = this.allDetectedItems.map(i => {
                const sub = (parseFloat(i.price) || 0) * i.qty;
                total += sub;
                return `${i.qty} x ${i.name} ($${i.price})`;
            });
            payload = {
                ORDER: {
                    Table: this.currentTable,
                    Items: items.join(', '),
                    Total: total + "$"
                }
            };
        } else if (type === 'BILL') {
            payload = {
                BILL: {
                    Table: this.currentTable
                }
            };
        } else if (type === 'COMPLAINT') {
            payload = {
                COMPLAINT: {
                    Table: this.currentTable,
                    Message: this.lastComplaint
                }
            };
        }

        const msg = JSON.stringify(payload, null, 2);
        const url = `https://api.telegram.org/bot${this.TELEGRAM_BOT_TOKEN}/sendMessage`;
        fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: this.TELEGRAM_GROUP_ID, text: "```\n" + msg + "\n```", parse_mode: 'MarkdownV2' })
        }).catch(e => console.error("Telegram Error", e));
    }
};

VoiceWaiter.init();
