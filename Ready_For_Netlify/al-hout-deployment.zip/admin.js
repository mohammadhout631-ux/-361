/**
 * Admin Panel Logic
 */

const Admin = {
    isLoggedIn: false,

    login: async function () {
        const pass = document.getElementById('admin-pass').value;
        const data = await RestaurantData.getData();

        if (pass === data.info.adminPassword) {
            this.isLoggedIn = true;
            document.getElementById('login-overlay').style.display = 'none';
            await this.init();
        } else {
            alert('❌ كلمة السر خاطئة!');
        }
    },

    logout: function () {
        if (confirm('هل تريد تسجيل الخروج؟')) {
            window.location.reload();
        }
    },

    init: async function () {
        const data = await RestaurantData.getData();
        this.fillInfo(data.info);
        await this.renderCategoriesList();
        await this.fillItemCategoryFilter();
        await this.renderItemsList();
    },

    showTab: function (tabName, event) {
        if (event) event.preventDefault();
        document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
        document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('active'));

        document.getElementById('tab-' + tabName).style.display = 'block';
        if (event) event.target.closest('.tab-link').classList.add('active');
    },

    // Restaurant Info
    fillInfo: function (info) {
        document.getElementById('info-name').value = info.name;
        document.getElementById('info-phone').value = info.phone;
        document.getElementById('info-address').value = info.address;
        document.getElementById('info-hours').value = info.openHours;


        // New fields
        document.getElementById('logo-text').value = info.logo ? info.logo.text : '';
        this.updateLogoPreview(info.logo ? info.logo.image : '');

        if (info.dailyDish) {
            document.getElementById('dd-active').checked = info.dailyDish.active;
            document.getElementById('dd-title').value = info.dailyDish.title;
            document.getElementById('dd-text').value = info.dailyDish.text;
        }
    },

    updateLogoPreview: function (src) {
        const preview = document.getElementById('logo-preview');
        if (src) {
            preview.innerHTML = `<img src="${src}" style="width:100%; height:100%; object-fit:contain;">`;
        } else {
            preview.innerHTML = `<i class="fas fa-image fa-2x" style="opacity:0.2;"></i>`;
        }
    },

    saveInfo: async function () {
        const data = await RestaurantData.getData();
        data.info.name = document.getElementById('info-name').value;
        data.info.phone = document.getElementById('info-phone').value;
        data.info.address = document.getElementById('info-address').value;
        data.info.openHours = document.getElementById('info-hours').value;

        // New fields
        data.info.logo.text = document.getElementById('logo-text').value;
        data.info.dailyDish.active = document.getElementById('dd-active').checked;
        data.info.dailyDish.title = document.getElementById('dd-title').value;
        data.info.dailyDish.text = document.getElementById('dd-text').value;

        if (await RestaurantData.saveData(data)) {
            alert('✅ تم حفظ المعلومات بنجاح');
        }
    },

    editLogo: function () {
        const input = document.getElementById('logo-upload-input');
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) { // Increased to 2MB since using IDB
                alert('⚠️ الصورة كبيرة جداً! يرجى اختيار صورة أصغر من 2 ميجابايت.');
                return;
            }
            const reader = new FileReader();
            reader.onload = async (event) => {
                const base64 = event.target.result;
                const data = await RestaurantData.getData();
                data.info.logo.image = base64;
                await RestaurantData.saveData(data);
                this.updateLogoPreview(base64);
                alert('✅ تم تحديث اللوغو بنجاح');
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    removeLogo: async function () {
        if (!confirm('هل تريد حذف صورة اللوغو؟')) return;
        const data = await RestaurantData.getData();
        data.info.logo.image = "";
        await RestaurantData.saveData(data);
        this.updateLogoPreview("");
    },

    editDailyDishMedia: function (type) {
        const input = document.getElementById('dd-media-input');
        input.accept = type === 'image' ? 'image/*' : 'video/*';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 10 * 1024 * 1024) { // Increased to 10MB for video in IDB
                alert('⚠️ الملف كبير جداً! الحد الأقصى 10 ميجابايت.');
                return;
            }
            const reader = new FileReader();
            reader.onload = async (event) => {
                const base64 = event.target.result;
                const data = await RestaurantData.getData();
                if (type === 'image') {
                    data.info.dailyDish.image = base64;
                    data.info.dailyDish.video = "";
                } else {
                    data.info.dailyDish.video = base64;
                    data.info.dailyDish.image = "";
                }
                await RestaurantData.saveData(data);
                alert('✅ تم رفع الميديا بنجاح');
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    removeDailyDishMedia: async function () {
        if (!confirm('هل تريد حذف ميديا طبق اليوم؟')) return;
        const data = await RestaurantData.getData();
        data.info.dailyDish.image = "";
        data.info.dailyDish.video = "";
        await RestaurantData.saveData(data);
        alert('✅ تم الحذف');
    },

    changePassword: async function () {
        const newPass = document.getElementById('new-password').value;
        if (!newPass) return alert('يرجى إدخال كلمة السر الجديدة');

        const data = await RestaurantData.getData();
        data.info.adminPassword = newPass;
        if (await RestaurantData.saveData(data)) {
            alert('✅ تم تحديث كلمة السر بنجاح. يرجى استخدامها في المرة القادمة.');
            document.getElementById('new-password').value = '';
        }
    },



    // Categories
    renderCategoriesList: async function () {
        const data = await RestaurantData.getData();
        const list = document.getElementById('categories-list');
        list.innerHTML = '';

        data.categories.sort((a, b) => a.order - b.order).forEach(cat => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${cat.order}</td>
                <td>
                    <div onclick="Admin.editCategoryImage('${cat.id}')" style="width:40px; height:40px; border:1px dashed #555; border-radius:5px; cursor:pointer; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#111;">
                        ${cat.image ? `<img src="${cat.image}" style="width:100%; height:100%; object-fit:cover;">` : '<i class="fas fa-image" style="opacity:0.3;"></i>'}
                    </div>
                </td>
                <td><input type="text" value="${cat.name}" onchange="Admin.updateCategoryName('${cat.id}', this.value)" style="width:100%; padding:5px; background:transparent; color:white; border:1px solid #333;"></td>
                <td>
                    <button onclick="Admin.deleteCategory('${cat.id}')" class="btn" style="background:var(--danger); padding:5px 10px;"><i class="fas fa-trash"></i></button>
                </td>
            `;
            list.appendChild(tr);
        });
    },

    addCategory: async function () {
        const name = prompt('أدخل اسم القسم الجديد:');
        if (!name) return;

        const data = await RestaurantData.getData();
        const newId = 'c_' + Date.now();
        data.categories.push({
            id: newId,
            name: name,
            order: data.categories.length + 1,
            image: ''
        });

        await RestaurantData.saveData(data);
        await this.renderCategoriesList();
        await this.fillItemCategoryFilter();
    },

    updateCategoryName: async function (id, newName) {
        const data = await RestaurantData.getData();
        const cat = data.categories.find(c => c.id === id);
        if (cat) cat.name = newName;
        await RestaurantData.saveData(data);
    },

    editCategoryImage: function (id) {
        const input = document.getElementById('category-image-input');
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) { // Increased for IDB
                alert('⚠️ الصورة كبيرة جداً! يرجى اختيار صورة أصغر من 2 ميجابايت.');
                return;
            }
            const reader = new FileReader();
            reader.onload = async (event) => {
                const base64 = event.target.result;
                const data = await RestaurantData.getData();
                const cat = data.categories.find(c => c.id === id);
                if (cat) cat.image = base64;
                if (await RestaurantData.saveData(data)) {
                    await this.renderCategoriesList();
                    alert('✅ تم تحديث صورة القسم بنجاح');
                }
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    deleteCategory: async function (id) {
        if (!confirm('هل أنت متأكد؟ سيتم حذف جميع الأصناف في هذا القسم!')) return;
        const data = await RestaurantData.getData();
        data.categories = data.categories.filter(c => c.id !== id);
        data.items = data.items.filter(i => i.categoryId !== id);
        await RestaurantData.saveData(data);
        await this.renderCategoriesList();
        await this.renderItemsList();
    },

    // Items
    fillItemCategoryFilter: async function () {
        const data = await RestaurantData.getData();
        const filter = document.getElementById('item-cat-filter');
        filter.innerHTML = '<option value="all">كل الأقسام</option>';
        data.categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.id;
            opt.innerText = cat.name;
            filter.appendChild(opt);
        });
    },

    renderItemsList: async function () {
        const data = await RestaurantData.getData();
        const list = document.getElementById('items-list');
        const filterId = document.getElementById('item-cat-filter').value;
        list.innerHTML = '';

        const filteredItems = filterId === 'all' ? data.items : data.items.filter(i => i.categoryId === filterId);

        filteredItems.forEach(item => {
            const cat = data.categories.find(c => c.id === item.categoryId);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${item.image ? `<img src="${item.image}" width="40">` : '<i class="fas fa-utensils"></i>'}</td>
                <td><input type="text" value="${item.name}" onchange="Admin.updateItem('${item.id}', 'name', this.value)" style="background:transparent; color:white; border:none; border-bottom:1px solid #333;"></td>
                <td><textarea onchange="Admin.updateItem('${item.id}', 'description', this.value)" style="background:transparent; color:#ccc; border:1px solid #333; height:40px; font-size:12px; width:100%; border-radius:4px;">${item.description || ''}</textarea></td>
                <td><input type="text" value="${item.price}" onchange="Admin.updateItem('${item.id}', 'price', this.value)" style="width:60px; background:transparent; color:var(--primary); border:none; border-bottom:1px solid #333;"></td>
                <td style="font-size:12px; color:#aaa;">${cat ? cat.name : 'بدون قسم'}</td>
                <td>
                    <button onclick="Admin.editItemImage('${item.id}')" class="btn" style="background:var(--primary); color:#000; padding:5px 10px;"><i class="fas fa-image"></i></button>
                    <button onclick="Admin.deleteItem('${item.id}')" class="btn" style="background:var(--danger); padding:5px 10px;"><i class="fas fa-trash"></i></button>
                </td>
            `;
            list.appendChild(tr);
        });
    },

    addItem: async function () {
        const data = await RestaurantData.getData();
        if (data.categories.length === 0) {
            alert('يرجى إنشاء قسم أولاً!');
            return;
        }

        const name = prompt('اسم الصنف الجديد:');
        if (!name) return;
        const price = prompt('السعر:');
        const catId = document.getElementById('item-cat-filter').value;
        const targetCatId = catId === 'all' ? data.categories[0].id : catId;

        const newItem = {
            id: 'i_' + Date.now(),
            categoryId: targetCatId,
            name: name,
            price: price || '0',
            description: '',
            image: ''
        };

        data.items.push(newItem);
        await RestaurantData.saveData(data);
        await this.renderItemsList();
    },

    updateItem: async function (id, field, value) {
        const data = await RestaurantData.getData();
        const item = data.items.find(i => i.id === id);
        if (item) item[field] = value;
        return await RestaurantData.saveData(data);
    },

    deleteItem: async function (id) {
        if (!confirm('هل أنت متأكد من حذف هذا الصنف؟')) return;
        const data = await RestaurantData.getData();
        data.items = data.items.filter(i => i.id !== id);
        await RestaurantData.saveData(data);
        await this.renderItemsList();
    },

    editItemImage: function (id) {
        const input = document.getElementById('item-image-input');
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Check file size (limit to 5MB since using IDB)
            if (file.size > 5 * 1024 * 1024) {
                alert('⚠️ الصورة كبيرة جداً! يرجى اختيار صورة أصغر من 5 ميجا بايت.');
                return;
            }

            const reader = new FileReader();
            reader.onload = async (event) => {
                const base64 = event.target.result;
                if (await this.updateItem(id, 'image', base64)) {
                    await this.renderItemsList();
                    alert('✅ تم تحديث الصورة بنجاح');
                }
            };
            reader.readAsDataURL(file);
        };
        input.click();
    },

    // Backup
    exportData: async function () {
        const json = await RestaurantData.exportData();
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `al-hout-menu-${new Date().toLocaleDateString()}.json`;
        a.click();
    },

    importData: function (input) {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (e) => {
            if (await RestaurantData.importData(e.target.result)) {
                alert('✅ تم استيراد البيانات بنجاح!');
                window.location.reload();
            } else {
                alert('❌ فشل استيراد البيانات!');
            }
        };
        reader.readAsText(file);
    }
};
